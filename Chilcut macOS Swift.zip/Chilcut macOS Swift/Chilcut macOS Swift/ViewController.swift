//
//  ViewController.swift
//  Chilcut macOS Swift
//
//  Created by WOS on 13/01/18.
//  Copyright © 2018 WOS. All rights reserved.
//

import Cocoa


class ViewController: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()


        let  rsa = CkoRsa()
        
        var success: Bool = rsa!.unlockComponent("Anything for 30-day trial")
        if success != true {
            print("\(String(describing: rsa?.lastErrorText))")
        }
        
        if (rsa?.unlockComponent("Anything for 30-day trial")) != nil {
            print("Error!")
        }
        
        let modulus: String? = "+dAjnVFk7KI1MNiDhQ8C/vfcLgH1ZihxKmMAqrZJFQ2FhDckcJ/Vfh4IBlNLxHI1zEJ1PawQCbqpjeFEwYx4mZM3t+F0L+vvIGycypoMyVFaH1bYj+J2yNUW0cpF1Re/ch86f86nMUjWw/o1kZ2+SKM+rhndmJayrUgUY23fLzE="
        let exponent: String? = "AQAB"
        
        
        let xml = CkoXml()
        xml?.tag = "RSAPublicKey"
        xml?.newChild2("Modulus", content: modulus)
        xml?.newChild2("Exponent", content: exponent)
        
        //  Encrypt with the public key.
        let publicKey: String? = xml?.getXml()
        success = (rsa?.importPublicKey(publicKey))!
        
        let usePrivateKey: Bool = false
        let plainText: String? = setEncrypted_PrivateKeyFormat() as String
        
        rsa?.encodingMode = "base64"
        let encryptedStrBase64: String? = rsa?.encryptStringENC(plainText, bUsePrivateKey: usePrivateKey)
        print("123: \(encryptedStrBase64!)")
        
        
    }

    // MARK: - Ency.Decp.
    func setEncrypted_PrivateKeyFormat() -> NSString {
        let strPrivateKey : NSString = "945c31eff54fb391b1a7c2e063d7302f43d38a45e73e2941c1b2409665b16fe7" as NSString
        
        var strCurretTimeInUnixFormat : NSString = "\(NSDate().timeIntervalSince1970)" as NSString
        let arrTime : NSArray = strCurretTimeInUnixFormat.components(separatedBy: ".") as NSArray
        strCurretTimeInUnixFormat = arrTime.firstObject as! NSString
        
        let strFinalValue : NSString = "\(strPrivateKey)|\(strCurretTimeInUnixFormat)" as NSString
        print("strFinalValue : \(strFinalValue)")
        
        let strEncrypted_PrivateKey : NSString = "aaaaaa"
        //strEncrypted_PrivateKey = self.EncyDecpy(strFormatedPrivateKey: strFinalValue)
        print("strEncrypted_PrivateKey : \(strEncrypted_PrivateKey)")
        
        return strFinalValue
    }
    
    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }


}

